import { BoxProps } from '@obridge/uikit'

export interface PageHeaderProps extends BoxProps {
  background?: string
}
