type SerializedBigNumber = string

declare let __NEZHA_BRIDGE__: any
