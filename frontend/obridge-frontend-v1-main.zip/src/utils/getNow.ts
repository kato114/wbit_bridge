export const getNow = () => Math.floor(Date.now() / 1000)
