export const perpTheme = (isDark: boolean) => {
  return isDark ? 'dark' : 'light'
}
