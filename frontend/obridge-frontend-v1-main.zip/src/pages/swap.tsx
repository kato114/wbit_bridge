import { CHAIN_IDS } from 'utils/wagmi'
import Bridge from '../views/Bridge'

const SwapPage = () => {
  return <Bridge/>
}

SwapPage.chains = CHAIN_IDS

export default SwapPage
