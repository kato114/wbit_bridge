// import { bscTestnetTokens } from '../tokens'
import { SerializedFarmConfig } from '../../types'

const priceHelperLps: SerializedFarmConfig[] = []

export default priceHelperLps
