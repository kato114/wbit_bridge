// import { serializeTokens } from 'utils/serializeTokens'
import { SerializedFarmConfig } from '../../types'
// import { ethereumTokens } from '../tokens'

// const serializedTokens = serializeTokens(ethereumTokens)

const priceHelperLps: SerializedFarmConfig[] = []

export default priceHelperLps
