const DELIST_COLLECTIONS = {
  '0x4D89eBf7b1F66806A4C99Df71D22b7b9efC6bB0b': {
    active: false,
    address: '0x4D89eBf7b1F66806A4C99Df71D22b7b9efC6bB0b',
    avatar: '',
    banner: {
      large: '',
      small: '',
    },
    createdAt: '',
    creatorAddress: '',
    creatorFee: '',
    description: '',
    id: '0x4d89ebf7b1f66806a4c99df71d22b7b9efc6bb0b',
    name: 'Baked Potatoes',
    numberTokensListed: '76',
    owner: '0xCd1B0abBc3E55E91FCC5AEE393525e68478C2952',
    symbol: 'POT',
    totalSupply: '',
    totalTrades: '',
    totalVolumeBNB: '',
    tradingFee: '',
    updatedAt: '',
    verified: true,
    whitelistChecker: '',
  },
}

export default DELIST_COLLECTIONS
